import SwiftUI
import PlaygroundSupport



struct ContentView:View {
    var body: some View{
        VStack{
            ListView()
        }
    }
}

let view = ContentView()
let vc = UIHostingController(rootView: view)
PlaygroundPage.current.liveView = vc

