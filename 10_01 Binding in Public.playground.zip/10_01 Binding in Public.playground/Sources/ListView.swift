import SwiftUI

public struct ListView:View {
    public var body: some View {
        List{
            ForEach(1...10,id: \.self){ item in
                RowView(item: item)
            }
        }
    }
}

